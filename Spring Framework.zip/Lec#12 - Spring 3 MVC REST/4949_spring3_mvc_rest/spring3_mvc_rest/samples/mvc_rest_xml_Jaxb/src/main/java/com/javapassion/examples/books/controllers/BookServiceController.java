package com.javapassion.examples.books.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.javapassion.examples.books.domain.Author;
import com.javapassion.examples.books.domain.Book;
import com.javapassion.examples.books.services.BookService;

@Controller
public class BookServiceController {
 
	@Autowired
	BookService bookService;
 
	@RequestMapping(value = "/books")
	public ModelAndView getAllBooks() {
		List<Book> books = bookService.getAllBooks();
		ModelAndView mav = 
			new ModelAndView("bookXmlView", "books", books);
		return mav;
	}
 
	@RequestMapping(value = "/books/{isbn}")
	public ModelAndView getBookByIsbn(@PathVariable String isbn) {
		Book book = bookService.getBookByIsbn(isbn);
		ModelAndView mav = 
			new ModelAndView("bookXmlView", "book", book);
		return mav;
	}
 
	@RequestMapping(value = "/authors")
	public ModelAndView getAllAuthors() {
		List<Author> authors = bookService.getAllAuthors();
		ModelAndView mav = 
			new ModelAndView("bookXmlView", "authors", authors);
		return mav;
	}
 
	@RequestMapping(value = "/authors/{authorId}")
	public ModelAndView getAuthorById(@PathVariable String authorId) {
		Author author = bookService.getAuthorById(authorId);
		ModelAndView mav = 
			new ModelAndView("bookXmlView", "author", author);
		return mav;
	}
 
	@RequestMapping(value = "/authors/{authorId}/books")
	public ModelAndView getBooksByAuthor(@PathVariable String authorId) {
		List<Book> books = bookService.getBooksByAuthor(authorId);
		ModelAndView mav = 
			new ModelAndView("bookXmlView", "books", books);
		return mav;
	}
}