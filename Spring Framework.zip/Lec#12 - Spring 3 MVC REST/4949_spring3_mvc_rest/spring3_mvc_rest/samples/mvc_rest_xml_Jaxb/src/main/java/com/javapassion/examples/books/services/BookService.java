package com.javapassion.examples.books.services;

import java.util.List;

import com.javapassion.examples.books.domain.Author;
import com.javapassion.examples.books.domain.Book;

public interface BookService {
	public Book getBookByIsbn(String isbn);
	public List<Book> getBooksByAuthor(String authorId);
	public List<Book> getAllBooks();
	public List<Author> getAllAuthors();
	public Author getAuthorById(String authorId);
}
