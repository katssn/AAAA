package com.javapassion.examples.books.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.javapassion.examples.books.domain.Address;
import com.javapassion.examples.books.domain.Author;
import com.javapassion.examples.books.domain.Book;
import com.javapassion.examples.books.domain.Publisher;


@Service
public class MockBookServiceImpl implements BookService {

	private static Map<String,Book> bookMap = Maps.newHashMap();
	private static ArrayListMultimap<String,Book> authorIdToBook = ArrayListMultimap.create();
	private static Map<String, Author> authorMap = Maps.newHashMap();

	static {

		List<Book> books = new ArrayList<Book>();
		List<Author> authors = new ArrayList<Author>();
		authors.add(new Author("1", "kathie Sierra", "ksierra@somedomain.com"));
		authors.add(new Author("2", "xys", "ksierra@somedomain.com"));
		Address address = new Address("x", "y", "x", "12345");
		Publisher publisher = new Publisher("Some company", address);
		Book b = new Book("0596009208", "Head First Java", 2, 688, "Nov. 2010", authors, publisher);

		books.add(b);
		
		for(Book book : books) {
			bookMap.put(book.getIsbn(), book);
			for(Author a : book.getAuthors()) {
				authorIdToBook.put(a.getAuthorId(), book);
				authorMap.put(a.getAuthorId(), a);
			}
		}

	}
	
	@Override
	public Book getBookByIsbn(String isbn) {
		return bookMap.get(isbn);
	}

	@Override
	public List<Book> getBooksByAuthor(String authorId) {
		return Lists.newArrayList(authorIdToBook.get(authorId));
	}

	@Override
	public List<Author> getAllAuthors() {
		return Lists.newArrayList(authorMap.values());
	}

	@Override
	public List<Book> getAllBooks() {
		return Lists.newArrayList(bookMap.values());
	}

	@Override
	public Author getAuthorById(String authorId) {
		return authorMap.get(authorId);
	}
}
