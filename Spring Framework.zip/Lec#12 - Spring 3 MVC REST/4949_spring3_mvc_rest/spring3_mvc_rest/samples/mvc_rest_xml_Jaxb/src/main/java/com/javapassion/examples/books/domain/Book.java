package com.javapassion.examples.books.domain;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Book {
	
	private String isbn;
	private String title;
	private int edition;
	private int pages;
	private String published;
	private List<Author> authors;
	private Publisher publisher;
	
	public Book() {
		super();
	}
	
	public Book(String isbn, String title, int edition, int pages,
			String published, List<Author> authors, Publisher publisher) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.edition = edition;
		this.pages = pages;
		this.published = published;
		this.authors = authors;
		this.publisher = publisher;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	public String getPublished() {
		return published;
	}
	public void setPublished(String published) {
		this.published = published;
	}
	public Publisher getPublisher() {
		return publisher;
	}
	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}
	public void setAuthors(List<Author> authors) {
		this.authors = new LinkedList<Author>(authors);
	}
	public List<Author> getAuthors() {
		return new LinkedList<Author>(authors);
	}
	public void setEdition(int edition) {
		this.edition = edition;
	}
	public int getEdition() {
		return edition;
	}
}
