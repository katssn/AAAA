package com.javapassion.examples;

public interface CounterService {

    public void increase();
    public int getCount();
}
