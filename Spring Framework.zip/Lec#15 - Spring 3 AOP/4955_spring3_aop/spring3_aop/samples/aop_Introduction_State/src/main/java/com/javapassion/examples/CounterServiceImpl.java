package com.javapassion.examples;

public class CounterServiceImpl implements CounterService {

    private int count = 0;

    public void increase() {
        count++;
    }

    public int getCount() {
        return count;
    }
}
