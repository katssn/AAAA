package com.javapassion.examples;

public interface GreetingService {
    public String sayHello(String name, String greetingWords);
    public String sayHello2(String name, String greetingWords);
}
