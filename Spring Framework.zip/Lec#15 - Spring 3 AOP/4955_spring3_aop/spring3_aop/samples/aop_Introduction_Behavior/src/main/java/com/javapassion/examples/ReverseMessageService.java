package com.javapassion.examples;

public interface ReverseMessageService {
    public String reverseMessage(String message);
}
