package com.javapassion.examples;

public interface ReverseNameService {
    public String reverseName(String name);
}
