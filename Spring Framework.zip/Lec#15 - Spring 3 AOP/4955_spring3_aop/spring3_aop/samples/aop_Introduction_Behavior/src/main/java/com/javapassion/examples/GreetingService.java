package com.javapassion.examples;

public interface GreetingService {
    public String sayHello(String name, String greetingWords);
}
