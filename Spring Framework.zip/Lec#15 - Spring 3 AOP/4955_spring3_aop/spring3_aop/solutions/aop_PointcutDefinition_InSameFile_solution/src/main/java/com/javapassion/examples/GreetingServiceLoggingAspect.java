package com.javapassion.examples;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;

@Aspect
@Order(1)
public class GreetingServiceLoggingAspect {

    private Log log = LogFactory.getLog(this.getClass());
    
    // Declare "loggingHello" pointcut 
    @Pointcut("execution(* GreetingService.sayHello(..))")
    private void loggingHello(){}
    
    // Declare "speakSomething" pointcut 
    @Pointcut("execution(* GreetingService.speakSomething(..))")
    private void speakSomethingPointcut(){}

    // Use "loggingHello" pointcut declaration in the advice
    @Before("loggingHello()")
    public void logBefore(JoinPoint joinPoint) {
    	String nameOfMethod = joinPoint.getSignature().getName();
    	String arguments = Arrays.toString(joinPoint.getArgs());
        log.info("Before1: " + nameOfMethod + " gets called with " + arguments);
    }
    
    // Use "loggingHello" pointcut declaration in the advice
    @AfterReturning("loggingHello()")
    public void logAfterReturning(JoinPoint joinPoint) {
    	String nameOfMethod = joinPoint.getSignature().getName();
    	String arguments = Arrays.toString(joinPoint.getArgs());
        log.info("AfterReturning1: " + nameOfMethod + " gets called with " + arguments);
    }
    
    @Before("speakSomethingPointcut()")
    public void logBefore2(JoinPoint joinPoint) {
    	String nameOfMethod = joinPoint.getSignature().getName();
    	String arguments = Arrays.toString(joinPoint.getArgs());
        log.info("Before1: " + nameOfMethod + " gets called with " + arguments);
    }
    
    @AfterReturning("speakSomethingPointcut()")
    public void logAfterReturning2(JoinPoint joinPoint) {
    	String nameOfMethod = joinPoint.getSignature().getName();
    	String arguments = Arrays.toString(joinPoint.getArgs());
        log.info("AfterReturning1: " + nameOfMethod + " gets called with " + arguments);
    }
    
}