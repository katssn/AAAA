package com.javapassion.examples;

public interface CapitalizeMessageService {
    public String capitalizeMessage(String message);
}
