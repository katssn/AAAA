package com.javapassion.examples;

public class CapitalizeMessageServiceImpl implements CapitalizeMessageService {
		
	public String capitalizeMessage(String message) {; 
		return message.toUpperCase();
    }

}
