INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1000, 100, 'SAVING', 3502.92, 'HDFC001', 'HDFC');
INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1001, 200, 'CURRENT', 3122.05, 'HDFC002', 'HDFC');
INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1002, 300, 'SAVING', 4553.43, 'HDFC003', 'HDFC');
INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1001, 101, 'SAVING', 3502.92, 'ICICI001', 'ICICI');
INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1004, 201, 'CURRENT', 3122.05, 'ICICI002', 'ICICI');
INSERT INTO ACCOUNTS (customerId, accountId, accountType, balance, branchCode, bank) values (1002, 301, 'SAVING', 4553.43, 'ICICI003', 'ICICI');
