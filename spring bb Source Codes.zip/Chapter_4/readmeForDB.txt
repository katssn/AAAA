Create a database in "accountsdb" in MySQL. 
Create a table "accounts" with the following columns

account_number int(4) auto_inc, primary key,
owner varchar(40),
balance double(40)
