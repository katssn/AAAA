package com.intro;

public interface Alarm 
{
	void activate();
	void deactivate();
}
