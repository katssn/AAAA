package com.ejbChapter;

public class WeatherReporterServiceImpl implements WeatherReporterService
{
	public void processTemperatureInfo(String information)
	{
		System.out.println(information);
	}
}
