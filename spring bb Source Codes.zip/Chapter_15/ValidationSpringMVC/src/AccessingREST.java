import org.springframework.web.client.RestTemplate;

public class AccessingREST 
{
	public static void main(String[] args) 
	{
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.postForLocation("http://localhost:8090/ValidationSpringMVC/mvc/Person/add?id=p8&name=Dobby",null);
		String str = restTemplate.getForObject("http://localhost:8090/ValidationSpringMVC/mvc/Person/{id}", String.class, "p8");
		System.out.println(str);

		restTemplate.delete("http://localhost:8090/ValidationSpringMVC/mvc/Person/add?id=p8");
		str = restTemplate.getForObject("http://localhost:8090/ValidationSpringMVC/mvc/Person/{id}", String.class, "p8");
		System.out.println(str);
	}
}
