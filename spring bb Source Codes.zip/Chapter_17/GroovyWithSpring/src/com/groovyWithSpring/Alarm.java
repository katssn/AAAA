package com.groovyWithSpring;

public interface Alarm 
{
	void activate();
	void deactivate();
}
