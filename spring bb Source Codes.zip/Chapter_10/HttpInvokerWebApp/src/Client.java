import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import com.remotingChapter.WeatherReporter;

public class Client 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("build/classes/client-beans.xml");
		WeatherReporter reporter = (WeatherReporter)context.getBean("weatherReporterBean");
		System.out.println(reporter.getTemperature("Chennai"));
	}
}
