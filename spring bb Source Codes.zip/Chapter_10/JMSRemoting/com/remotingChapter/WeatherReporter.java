package com.remotingChapter;

public interface WeatherReporter
{
	String getTemperature(String city);
}