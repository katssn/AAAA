import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Host
{
	public static void main(String[] args)
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("build/classes/jaxws-servlet.xml");
		System.out.println("Waiting for requests");
	}
}
