package com.rmiChapter.service;

import java.rmi.RemoteException;
import com.rmiChapter.WeatherReporter;

public class WeatherReporterImpl implements WeatherReporter
{
	public String getTemperature(String city) throws RemoteException 
	{
		return "Temperature of " + city + " is " + Math.random()*100;
	}
}
