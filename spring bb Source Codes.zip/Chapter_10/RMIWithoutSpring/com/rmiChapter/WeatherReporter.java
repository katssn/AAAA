package com.rmiChapter;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface WeatherReporter extends Remote
{
	String getTemperature(String city)throws RemoteException;
}
