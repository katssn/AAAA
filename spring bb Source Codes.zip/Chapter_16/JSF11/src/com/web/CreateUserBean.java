package com.web;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.jsf.FacesContextUtils;

import com.dao.UserDao;

public class CreateUserBean 
{
	private String email;
	private String password;
	private String password2;
	private UserDao userDao;
	
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public String action()
	{
		String forwardPage = "Success";
		String errorMessage = "";
		if(!password.equals(password2))
		{
			forwardPage = "Failure";
			errorMessage = "Passwords do not match";
		}
		try
		{
			//This option can also be used if DelegatingVariableResolver is not configured
			/*FacesContext fc = FacesContext.getCurrentInstance();
			userDao = (UserDao)FacesContextUtils.getWebApplicationContext(fc).getBean("userDaoBean");
			*/
			
			userDao.insertUser(email, password);
		}
		catch(Exception ex)
		{
			forwardPage = "Failure";
			errorMessage = ex.getMessage();
		}
		if("Failure".equals(forwardPage))
		{
			HttpServletRequest request =
				(HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.setAttribute("errorMessage", errorMessage);
		}
		return forwardPage;
	}
	
}
