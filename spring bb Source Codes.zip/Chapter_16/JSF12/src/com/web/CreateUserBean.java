package com.web;

import javax.faces.context.FacesContext;

import org.springframework.web.jsf.FacesContextUtils;

import com.dao.UserDao;

public class CreateUserBean 
{
	private String email;
	private String password;
	private String password2;
	private UserDao userDao;
	
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public String action()
	{
		System.out.println("****" + userDao);
		System.out.println(FacesContextUtils.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean("userDaoBean"));
		if(!password.equals(password2))
			return "Failure";
		return "Success";
	}
	
}
