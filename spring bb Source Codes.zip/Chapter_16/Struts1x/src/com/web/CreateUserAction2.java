package com.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;

import com.beans.User;
import com.dao.UserDao;

public class CreateUserAction2 extends ActionSupport
{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
	{
		User userActionForm = (User)form;
		String errorMessage = "";
		String forwardPage = "Success";
		if(!userActionForm.getPassword().equals(userActionForm.getPassword2()))
		{
			errorMessage = "Passwords do not match. Try again";
			forwardPage = "Failure";
		}
		else
		{
			UserDao userDao = (UserDao) super.getWebApplicationContext().getBean("userDaoBean");
			try
			{
				userDao.insertUser(userActionForm.getEmail(), userActionForm.getPassword());
			}
			catch(Exception ex)
			{
				errorMessage = ex.getMessage();
				forwardPage = "Failure";
			}
		}
		if("Failure".equals(forwardPage))
			request.setAttribute("errorMessage",errorMessage);
		
		return mapping.findForward(forwardPage);
	}
}
