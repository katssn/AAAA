package com.beans;

public class InvalidUserException extends RuntimeException
{
	
}
