package com.beans;

public class EmployeeLoginBean 
{
	private EmployeeId empId;
	private String password;
	
	public EmployeeId getEmpId() {
		return empId;
	}
	public void setEmpId(EmployeeId empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
