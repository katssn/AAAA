package com.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.beans.Person;

@Controller("/CreatePerson")
public class CreatePersonController
{
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView createPerson(HttpServletRequest request)
	{
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age").toString());
		String message = "Hi " + name + "!! You are " + age + " years old";
		return new ModelAndView("display","message",message);
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView createPerson(@ModelAttribute Person person)
	{
		String message = "Hi " + person.getName() + "!! You are " + person.getAge() + " years old";
		return new ModelAndView("display","message",message);
	}
	
	
	
}
