package com.web;

import java.util.Hashtable;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Persons")
public class PersonsController 
{
	private Hashtable<String, String> persons = new Hashtable<String, String>();
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	@ResponseBody
	public String createPerson(@RequestParam("id")String id,@RequestParam("name")String name)
	{
		persons.put(id, name);
		return "Person added Successfully";
	}
	
	@RequestMapping(value="/get/{id}",method=RequestMethod.GET)
	@ResponseBody
	public String getPerson(@PathVariable("id")String id)
	{
		String person = "Not Found";
		if(persons.containsKey(id))
			person = persons.get(id);
		return person;
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	@ResponseBody
	public String deletePerson(@PathVariable("id")String id)
	{
		persons.remove(id);
		return "Person removed Successfully";
	}
	
	@RequestMapping(value="/update/{id}/{name}",method=RequestMethod.PUT)
	@ResponseBody
	public String updatePerson(@PathVariable("id")String id,@PathVariable("name")String name)
	{
		persons.remove(id);
		persons.put(id, name);
		return "Person updated Successfully";
	}
	
}
