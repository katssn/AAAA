### Spring Boot CLI

Just execute the following command:

```java
spring run *.java
```


