// Ultimate client-side JavaScript client sniff. 
// (C) Netscape Communications 1999.  Permission granted to reuse and distribute. 
// Revised 17 May 99 to add is.nav5up and is.ie5up (see below). 
// From http://developer.netscape.com/tech/dynhtml/index.html.
//
// With un-needed code removed on 10-Dec-1999 by Araxis Ltd (djn).

function GetBrowserCaps() 
{
	// convert all characters to lowercase to simplify testing 
    var agt=navigator.userAgent.toLowerCase(); 

    // *** BROWSER VERSION *** 
    // Note: On IE5, these return 4, so use is.ie5up to detect IE5. 
    this.major = parseInt(navigator.appVersion); 
    this.minor = parseFloat(navigator.appVersion); 

    this.nav  = ((agt.indexOf('mozilla')!=-1) && (agt.indexOf('spoofer')==-1) 
                && (agt.indexOf('compatible') == -1) && (agt.indexOf('opera')==-1) 
                && (agt.indexOf('webtv')==-1)); 
    this.nav2 = (this.nav && (this.major == 2)); 
    this.nav3 = (this.nav && (this.major == 3)); 
    this.nav4 = (this.nav && (this.major == 4)); 
    this.nav4up = (this.nav && (this.major >= 4)); 
    this.navonly      = (this.nav && ((agt.indexOf(";nav") != -1) || 
                          (agt.indexOf("; nav") != -1)) ); 
    this.nav5 = (this.nav && (this.major == 5)); 
    this.nav5up = (this.nav && (this.major >= 5)); 

    this.ie   = (agt.indexOf("msie") != -1); 
    this.ie3  = (this.ie && (this.major < 4)); 
    this.ie4  = (this.ie && (this.major == 4) && (agt.indexOf("msie 5.0")==-1) ); 
    this.ie4up  = (this.ie  && (this.major >= 4)); 
    this.ie5  = (this.ie && (this.major == 4) && (agt.indexOf("msie 5.0")!=-1) ); 
    this.ie5up  = (this.ie  && !this.ie3 && !this.ie4); 
} 

function GetCSS()
{
	var u;
	if (bc.ie4up)
	{	
		u="ie4"
	}
	else if (bc.nav4up)
	{
		u="nn4"
	}
	else
		u="min";
		
	if (u != "min")
	{
		document.write ("<LINK rel=StyleSheet type='text/css' media='screen' href=araxis1_" + u + ".css>");	
	}
}

var bc = new GetBrowserCaps();
GetCSS();
