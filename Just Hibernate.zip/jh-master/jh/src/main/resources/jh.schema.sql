-- CREATE a JH schema
CREATE SCHEMA JH;

-- todo: need to add all the relevant tables here