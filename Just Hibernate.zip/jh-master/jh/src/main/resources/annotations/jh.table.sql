--Employee Table
drop table employee;

CREATE TABLE employee (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(50) DEFAULT NULL,
  PRIMARY KEY (id)
) ;

