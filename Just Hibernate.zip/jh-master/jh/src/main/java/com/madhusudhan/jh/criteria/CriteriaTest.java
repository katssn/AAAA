package com.madhusudhan.jh.criteria;

public class CriteriaTest {
	
	public static void main(String[] args) {
		
	}

}
