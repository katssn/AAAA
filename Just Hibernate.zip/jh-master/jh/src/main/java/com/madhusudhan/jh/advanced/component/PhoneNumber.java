/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jh.advanced.component;

/**
 *
 * @author mkonda
 */
public class PhoneNumber {
    private int areaCode = 0;
    private int phoneNumber = 0;
    private String name = null;
    
}
