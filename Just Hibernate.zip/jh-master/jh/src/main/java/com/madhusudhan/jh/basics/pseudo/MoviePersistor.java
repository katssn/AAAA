package com.madhusudhan.jh.basics.pseudo;

import com.madhusudhan.jh.domain.Movie;

public class MoviePersistor {

    public void perist(Movie movie) {
		// persisting mechanism goes here..
	}
	
	public void fetch(String title) {
		// fetching a movie by title mechanism goes here..
	}
}