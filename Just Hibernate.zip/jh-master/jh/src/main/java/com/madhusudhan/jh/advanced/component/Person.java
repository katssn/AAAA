/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jh.advanced.component;

/**
 *
 * @author mkonda
 */
public class Person {

    private int id = 0;
    private String firstName = null;
    private String lastName = null;
    private String nickName = null;
//    private int areaCode = 0;
//    private int phoneNumber = 0;
//    private String name = null;
    private PhoneNumber homePhone = null;
    private PhoneNumber mobilePhone  = null;
}
