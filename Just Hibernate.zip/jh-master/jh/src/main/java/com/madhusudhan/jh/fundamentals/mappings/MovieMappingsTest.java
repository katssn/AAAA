package com.madhusudhan.jh.fundamentals.mappings;

import org.junit.Test;

public class MovieMappingsTest {

	@Test
	public void createMapping(){
		
	}
}
