package com.beans;

public class EmployeeId 
{
	private String code;
	private long categorynumber;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public long getCategorynumber() {
		return categorynumber;
	}
	public void setCategorynumber(long number) {
		this.categorynumber = number;
	}
}
