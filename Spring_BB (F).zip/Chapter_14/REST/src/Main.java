import org.springframework.web.client.RestTemplate;

public class Main 
{
	public static void main(String[] args) 
	{
		RestTemplate rest = new RestTemplate();
		rest.postForLocation("http://localhost:8090/SpringMvc3/mvc/Persons/create?id=101&name=Sam", null);
		rest.postForLocation("http://localhost:8090/SpringMvc3/mvc/Persons/create?id=102&name=Sam", null);
		System.out.println(rest.getForObject("http://localhost:8090/SpringMvc3/mvc/Persons/get/{id}", String.class,"101"));
		
		System.out.println("After updating");
		rest.put("http://localhost:8090/SpringMvc3/mvc/Persons/update/101/Prabhu", null);
		System.out.println(rest.getForObject("http://localhost:8090/SpringMvc3/mvc/Persons/get/101", String.class));
		
		System.out.println("After deleting");
		rest.delete("http://localhost:8090/SpringMvc3/mvc/Persons/delete/{id}","101");
		System.out.println(rest.getForObject("http://localhost:8090/SpringMvc3/mvc/Persons/get/{id}", String.class,"101"));
	}
}
