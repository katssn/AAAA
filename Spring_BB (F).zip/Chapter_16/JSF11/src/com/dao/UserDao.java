package com.dao;

import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

public class UserDao extends SimpleJdbcDaoSupport
{
	public void insertUser(String email,String password)
	{
		getSimpleJdbcTemplate().update("insert into users values(?,?)", email,password);
	}
}
