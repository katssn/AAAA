package com.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.beans.User;
import com.dao.UserDao;

public class CreateUserAction3 extends Action
{
	private UserDao userDao;
	
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
	{
		User userActionForm = (User)form;
		String errorMessage = "";
		String forwardPage = "Success";
		if(!userActionForm.getPassword().equals(userActionForm.getPassword2()))
		{
			errorMessage = "Passwords do not match. Try again";
			forwardPage = "Failure";
		}
		else
		{
			try
			{
				userDao.insertUser(userActionForm.getEmail(), userActionForm.getPassword());
			}
			catch(Exception ex)
			{
				errorMessage = ex.getMessage();
				forwardPage = "Failure";
			}
		}
		if("Failure".equals(forwardPage))
			request.setAttribute("errorMessage",errorMessage);
		
		return mapping.findForward(forwardPage);
	}
}
