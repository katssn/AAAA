package com.ejbChapter;

public interface TemperatureProvider 
{
	String getTemperature(String city);
}
