package com.ejbChapter;

import javax.ejb.EJBObject;

public interface Account extends EJBObject,AccountService
{}
