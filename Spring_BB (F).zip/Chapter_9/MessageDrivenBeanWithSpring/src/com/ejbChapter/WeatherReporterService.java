package com.ejbChapter;

public interface WeatherReporterService {

	void processTemperatureInfo(String information);

}