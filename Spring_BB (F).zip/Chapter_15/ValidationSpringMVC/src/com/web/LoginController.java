package com.web;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.beans.Login;

@Controller
@RequestMapping("/Login.spring")
public class LoginController 
{

	@ModelAttribute("loginCommand")
	public Login getLoginBean()
	{
		return new Login();
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public String index()
	{
		return "login";
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String process(@Valid @ModelAttribute("login")Login login,BindingResult bindingResult)
	{
		if(bindingResult.hasErrors())
		{	
			bindingResult.rejectValue("userId", "Size.login.userId");
			bindingResult.reject("loginCommand.userId", "Invalid u");
			bindingResult.reject("loginCommand.password", "Invalid p");
			bindingResult.rejectValue("password", "Size.login.password");
			System.out.println(bindingResult);
			bindingResult.reject("form.problems");
			System.out.println("--- "  );
			for(String str : bindingResult.resolveMessageCodes("Size", ""))
			{
				System.out.println(str);
			}
			//bindingResult.rejectValue("userId","Invalid");
			//bindingResult.rejectValue(bindingResult.getFieldError("userId").getField(),"error");
				return "login";
		
		}
		return "success";
	}
}
