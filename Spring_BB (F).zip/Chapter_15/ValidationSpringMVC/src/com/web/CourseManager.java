package com.web;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Course")
public class CourseManager 
{
	private Map<String, String> students;
	
	public CourseManager()
	{
		students = new HashMap<String, String>();
	}
	
	@RequestMapping(value="/register",method=RequestMethod.POST)
	@ResponseBody
	public String register(@RequestParam("id") String id,@RequestParam("name") String name)
	{
		if(!students.containsKey(id))
		{
			students.put(id,name);
			return id + "Registered successfully";
		}
		return "Id : " + id  + " already registered for the course";
	}
	
	@RequestMapping(value="/getStudentInfo/{id}",method=RequestMethod.GET)
	@ResponseBody
	public String getStudentInfo(@PathVariable String id)
	{
		if(students.containsKey(id))
			return "Name : " + students.get(id);
		
		return id + " not registered for the course";
	}
	
	@RequestMapping(value="/cancel/{id}",method=RequestMethod.GET)
	@ResponseBody
	public String cancelRegistration(@PathVariable String id)
	{
		if(students.containsKey(id))
		{
			students.remove(id);
			return "Registration cancelled for " + id;	
		}
		return "Id : " + id + " does not exist!!";
	}
}
