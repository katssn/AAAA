package com.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Person")
public class PersonController 
{
	private Map<String, String> personMap;
	
	public PersonController()
	{
		System.out.println("***************");
		personMap = new HashMap<String, String>();
		personMap.put("p1", "Sam");
		personMap.put("p2", "John");
		personMap.put("p3", "Ram");
		personMap.put("p4", "Mary");
	}
	
	@RequestMapping(value="/{id}",method=RequestMethod.GET)
	@ResponseBody
	public String getPersonName(@PathVariable String id)
	{
		System.out.println("Id : ");
		return personMap.get(id);
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public String addPerson(@RequestParam("id") String id,@RequestParam("name") String name)
	{
		personMap.put(id, name);
		return "Successfully added";
	}
	@RequestMapping(value="/remove",method=RequestMethod.DELETE)
	@ResponseBody
	public String removePerson(@RequestParam("id") String id)
	{
		personMap.remove(id);
		return "Successfully removed";
	}
	
}
