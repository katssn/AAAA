package com.beans;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Login 
{
	@NotNull
	@Size(max=12,min=8)
	private String userId;
	@NotNull
	@Size(max=8,min=6)
	private String password;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
