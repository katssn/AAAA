package com.spelWithSpring;

public class RV extends Vehicle 
{}
