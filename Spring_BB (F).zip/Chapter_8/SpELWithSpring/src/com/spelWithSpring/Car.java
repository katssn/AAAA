package com.spelWithSpring;

public class Car extends Vehicle
{}
