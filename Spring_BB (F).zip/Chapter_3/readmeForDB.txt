Create a database in "employeesdb" in MySQL. 
Create a table "employees" with the following columns

id int(4) auto_inc, primary key,
first_name varchar(40),
last_name varchar(40),
designation varchar(40)