package com.beans;

public interface Alarm 
{
	void activate();
	void deactivate();
}
