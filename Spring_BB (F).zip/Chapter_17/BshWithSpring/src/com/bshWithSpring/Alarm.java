package com.bshWithSpring;

public interface Alarm 
{
	void activate();
	void deactivate();
}
