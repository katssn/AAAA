import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.rmiChapter.WeatherReporter;

public class Client 
{
	public static void main(String[] args) 
	{
		if(System.getSecurityManager() == null)
			System.setSecurityManager(new SecurityManager());
		try 
		{
			Registry registry = LocateRegistry.getRegistry();
			WeatherReporter reporter =(WeatherReporter) registry.lookup("CoolReporter");
			System.out.println(reporter.getTemperature("Chennai"));
		} 
		catch (AccessException e) 
		{
			e.printStackTrace();
		} 
		catch (RemoteException e) 
		{
			e.printStackTrace();
		} 
		catch (NotBoundException e) 
		{
			e.printStackTrace();
		}

	}
}
