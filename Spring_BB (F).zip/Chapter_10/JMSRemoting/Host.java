import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Host
{
	public static void main(String[] args)throws IOException
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("beans.xml");
		System.out.println("Waiting for requests");
		
		System.in.read();//To keep the program running
	}
}
