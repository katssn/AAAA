package com.remotingChapter.service;

import com.remotingChapter.WeatherReporter;

public class WeatherReporterImpl implements WeatherReporter
{
	public String getTemperature(String city) 
	{
		System.out.println("Gettemperature called");
		return "Temperature of  " + city + " is " + Math.random()*100;
	}
}
