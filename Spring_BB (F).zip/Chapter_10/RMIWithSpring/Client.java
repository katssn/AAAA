import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.rmiChapter.WeatherReporter;

public class Client 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("client-beans.xml");
		WeatherReporter reporter = (WeatherReporter)context.getBean("weatherReporterBean");
		System.out.println(reporter.getTemperature("Chennai"));
	}
}
