package com.rmiChapter;

public interface WeatherReporter 
{
	String getTemperature(String city);
}
