package com.rmiChapter.service;

import com.rmiChapter.WeatherReporter;

public class WeatherReporterImpl implements WeatherReporter
{
	public String getTemperature(String city) 
	{
		return "Temperature of  " + city + " is " + Math.random()*100;
	}
}
