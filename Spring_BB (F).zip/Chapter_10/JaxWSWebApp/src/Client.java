import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Client 
{
	public static void main(String[] args) 
	{
		ApplicationContext context = new FileSystemXmlApplicationContext("build/classes/client-beans.xml");
		//WeatherReporter reporter = (WeatherReporter)context.getBean("weatherReporterBean");
		  System.out.println(context.getBean("weatherReporterBean")); 
		com.remotingChapter.service.proxy.CoolReporter reporter = (com.remotingChapter.service.proxy.CoolReporter)context.getBean("weatherReporterBean");
		System.out.println(reporter.getTemperature("Chennai"));
	}
}
