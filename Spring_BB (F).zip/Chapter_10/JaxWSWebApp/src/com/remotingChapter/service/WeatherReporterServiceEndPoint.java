package com.remotingChapter.service;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;

import com.remotingChapter.WeatherReporter;

@WebService(name="CoolReporter",targetNamespace="http://www.myweatherservice.com")
@SOAPBinding(parameterStyle=ParameterStyle.BARE)
public class WeatherReporterServiceEndPoint 
{
	private WeatherReporter weatherReporter;

	public void setWeatherReporter(WeatherReporter weatherReporter) {
		this.weatherReporter = weatherReporter;
	}
	@WebMethod()
	public String getTemperature(String city)
	{
		return weatherReporter.getTemperature(city);
	}
}
