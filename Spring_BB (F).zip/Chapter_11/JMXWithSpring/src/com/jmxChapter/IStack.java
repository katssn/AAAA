package com.jmxChapter;

public interface IStack 
{
	int getSize();
	void pushItem(String item);
	String popItem();
}
