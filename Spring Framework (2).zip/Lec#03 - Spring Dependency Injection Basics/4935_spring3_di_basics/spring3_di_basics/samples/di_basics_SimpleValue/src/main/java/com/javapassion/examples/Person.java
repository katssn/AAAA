package com.javapassion.examples;

public class Person {
	String name;
	int age;
	float height;
	boolean isProgrammer;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public boolean getIsProgrammer() {
		return isProgrammer;
	}
	public void setIsProgrammer(boolean isProgrammer) {
		this.isProgrammer = isProgrammer;
	}

}
