package org.springframework.samples.petclinic;

/**
 * @author Juergen Hoeller
 */
public class PetType extends NamedEntity {

}
