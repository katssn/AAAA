package com.javapassion.examples.account;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.javapassion.examples.account.repository.AccountRepository;
import com.javapassion.examples.account.repository.InMemoryAccountRepository;
import com.javapassion.examples.account.service.TransferService;
import com.javapassion.examples.account.service.TransferServiceImpl;

@Configuration
public class AppConfig {

	@Bean(name="myTransferService")
	public TransferService transferService() {
		return new TransferServiceImpl(accountRepository());
	}

	@Bean
	public AccountRepository accountRepository() {
		return new InMemoryAccountRepository();
	}

}
