package com.javapassion.examples.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javapassion.examples.dao.CustomerDao;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDao customerDao;

	public String getCustomerGreeting() {
		String greeting = "Hello, " + customerDao.getCustomerName();
		return greeting;
	}

}
