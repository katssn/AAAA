package com.javapassion.examples.account.validators;

import java.util.Date;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.javapassion.examples.account.domain.Account;

public class AccountValidator implements Validator{

	public boolean supports(Class clazz) {
		//just validate the Account instances
		return Account.class.isAssignableFrom(clazz);

	}

	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name",
				"required.userName", "Field name is required.");
		
		Account account = (Account)target;
		
		if(account.getRenewalDate().before(new Date())){
			errors.rejectValue("renewalDate", 			// field name
							   "value.renewalDate"); // error code
		}
		
	}
	
}