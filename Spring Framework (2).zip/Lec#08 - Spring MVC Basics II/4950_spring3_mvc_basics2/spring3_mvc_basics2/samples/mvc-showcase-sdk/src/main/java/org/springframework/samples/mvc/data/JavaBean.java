package org.springframework.samples.mvc.data;

import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.tostring.RooToString;

@RooJavaBean
@RooToString
public class JavaBean {

	private String param1;
	
	private String param2;
	
	private String param3;
	
}
