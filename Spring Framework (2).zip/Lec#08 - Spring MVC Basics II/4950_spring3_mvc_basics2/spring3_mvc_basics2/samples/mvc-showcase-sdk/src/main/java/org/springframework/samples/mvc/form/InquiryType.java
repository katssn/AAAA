package org.springframework.samples.mvc.form;

public enum InquiryType {
	comment, feedback, suggestion;
}